package com.example.magicscene;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {
    String BASE_URL = "https://10.0.2.2/NOME Do WEB SERVIcES/";
    @GET("NOME DA ROTA")
    Call<List<Results>> getSuperHeroes();
}